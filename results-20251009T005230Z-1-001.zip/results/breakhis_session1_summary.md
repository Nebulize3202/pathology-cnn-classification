# BreakHis Dataset - Session 1 Summary

**Date:** 2025-10-07
**Dataset:** Breast Cancer Histopathological Database (BreakHis)
**Status:** ✅ Downloaded and Initial Analysis Complete

---

## Dataset Overview

- **Total Images:** 7,909
- **Total Patients:** 82
- **Image Format:** PNG
- **Image Size:** 700×460 pixels
- **Magnifications:** 40X, 100X, 200X, 400X

---

## Class Distribution

### Overall
- **Benign:** 2,480 images (31.4%)
- **Malignant:** 5,429 images (68.6%)
- **Imbalance Ratio:** 1:2.19 (Benign : Malignant)

### Per Magnification
- 40X: Benign=625, Malignant=1,370
- 100X: Benign=644, Malignant=1,437
- 200X: Benign=623, Malignant=1,390
- 400X: Benign=588, Malignant=1,232

---

## Patients
- **Benign Patients:** 24
- **Malignant Patients:** 58

---

## Tumor Subtypes

### Benign
- Tubular Adenoma: 569 images
- Phyllodes Tumor: 453 images
- Fibroadenoma: 1,014 images
- Adenosis: 444 images

### Malignant
- Mucinous Carcinoma: 792 images
- Ductal Carcinoma: 3,451 images
- Papillary Carcinoma: 560 images
- Lobular Carcinoma: 626 images

---

## Quality Check
- **Corrupted Images:** {len(corrupted)}
- **All Images Readable:** {len(corrupted)==0}
- **Image Sizes:** Mostly 700×460 pixels (few variations)

---

*This document was automatically generated from the BreakHis dataset analysis session.*
